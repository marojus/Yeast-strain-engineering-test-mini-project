```python
"Step 1 — Create a realistic yeast strain dataset (using pandas)"
```




    'Step 1 — Create a realistic yeast strain dataset (using pandas)'




```python

```


```python
#Step 1 — Create a realistic yeast strain dataset (using pandas)#
import pandas as pd
import numpy as np

np.random.seed(42)

# Number of engineered strains
n = 25

df = pd.DataFrame({
    "Strain_ID": [f"YS_{i+1}" for i in range(n)],

    # Phenotype features
    "Titer_gL": np.round(np.random.normal(3.5, 1.0, n), 2),          # product titer
    "GrowthRate_per_hr": np.round(np.random.normal(0.45, 0.08, n), 3),
    "StressTolerance": np.round(np.random.uniform(0.4, 0.95, n), 2),

    # Genotype features
    "Edit_Count": np.random.randint(1, 6, n),                        # number of edits
    "Pathway_Target": np.random.choice(["Mevalonate", "Shikimate", "Glycolysis"], n)
})

print(df.head())

```

      Strain_ID  Titer_gL  GrowthRate_per_hr  StressTolerance  Edit_Count  \
    0      YS_1      4.00              0.459             0.48           3   
    1      YS_2      3.36              0.358             0.84           1   
    2      YS_3      4.15              0.480             0.44           5   
    3      YS_4      5.02              0.402             0.94           2   
    4      YS_5      3.27              0.427             0.82           3   
    
      Pathway_Target  
    0      Shikimate  
    1     Mevalonate  
    2      Shikimate  
    3     Mevalonate  
    4     Mevalonate  



```python
#Step 2 — Prepare it for ML (encode + scale)#

from sklearn.preprocessing import RobustScaler
from sklearn.preprocessing import OneHotEncoder

# One-hot encode the pathway column
df_encoded = pd.get_dummies(df, columns=["Pathway_Target"])

# Select numeric features for clustering
X = df_encoded.drop(columns=["Strain_ID"])

#Step 3 — PCA + K‑means pipeline#
from sklearn.pipeline import Pipeline
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans

pipeline = Pipeline([
    ("scale", RobustScaler()),
    ("pca", PCA(n_components=2)),
    ("kmeans", KMeans(n_clusters=3, random_state=42))
])

pipeline.fit(X)
labels = pipeline["kmeans"].labels_

df["Cluster"] = labels
print(df[["Strain_ID", "Cluster"]].head())

```

      Strain_ID  Cluster
    0      YS_1        1
    1      YS_2        2
    2      YS_3        1
    3      YS_4        2
    4      YS_5        2



```python
#step 4 visualization clusters#
import matplotlib.pyplot as plt

# Get PCA coordinates
pca_coords = pipeline["pca"].transform(X)

# Plot clusters
plt.figure(figsize=(6, 5))
plt.scatter(pca_coords[:, 0], pca_coords[:, 1],
            c=labels, cmap="viridis", s=80, edgecolors="k")

plt.title("Yeast Strain Clusters (PCA Projection)")
plt.xlabel("Principal Component 1")
plt.ylabel("Principal Component 2")
plt.colorbar(label="Cluster ID")
plt.show()

```


![png](output_4_0.png)



```python
#We finished:Create dataset-->Encode + scale-->PCA + K‑means-->Visualize clusters#

```


```python
#Step 5 — Biological Interpretation of Your Clusters#
cluster_summary = df.groupby("Cluster").mean(numeric_only=True)
print(cluster_summary)

```

             Titer_gL  GrowthRate_per_hr  StressTolerance  Edit_Count
    Cluster                                                          
    0        2.225714           0.402571         0.598571    4.142857
    1        4.023750           0.485000         0.600000    3.000000
    2        3.567000           0.397800         0.754000    3.100000



```python
#Step 6 — Add Omics‑Style Features (optional next step)#
df["GeneExp_MevA"] = np.round(np.random.normal(50, 10, n), 1)
df["Flux_MVA"] = np.round(np.random.normal(3.0, 0.7, n), 2)

#re run PCA+K means fo rclearer biological structure#
#Step 3 — PCA + K‑means pipeline#
from sklearn.pipeline import Pipeline
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans

pipeline = Pipeline([
    ("scale", RobustScaler()),
    ("pca", PCA(n_components=2)),
    ("kmeans", KMeans(n_clusters=3, random_state=42))
])

pipeline.fit(X)
labels = pipeline["kmeans"].labels_

df["Cluster"] = labels
print(df[["Strain_ID", "Cluster"]].head())
```

      Strain_ID  Cluster
    0      YS_1        1
    1      YS_2        2
    2      YS_3        1
    3      YS_4        2
    4      YS_5        2



```python
#add omics feature#
# Add transcriptomics, proteomics, and metabolomics features
df["GeneExp_MevA"] = np.round(np.random.normal(50, 10, n), 1)       # transcript level of MevA gene
df["Flux_MVA"] = np.round(np.random.normal(3.0, 0.7, n), 2)         # metabolic flux through MVA pathway
df["Protein_MevA"] = np.round(np.random.normal(120, 25, n), 1)      # MevA protein abundance
df["Metabolite_MVA"] = np.round(np.random.normal(2.5, 0.6, n), 2)   # key metabolite concentration
df["EnzymeActivity_MevA"] = np.round(np.random.normal(80, 15, n), 1) # enzyme activity score

# Re‑encode and rerun PCA + K‑means
df_encoded = pd.get_dummies(df, columns=["Pathway_Target"])
X = df_encoded.drop(columns=["Strain_ID"])

pipeline.fit(X)
labels = pipeline["kmeans"].labels_
df["Cluster"] = labels

# Summarize cluster means for omics features
cluster_summary = df.groupby("Cluster").mean(numeric_only=True)
print(cluster_summary[["Titer_gL", "GeneExp_MevA", "Flux_MVA", "Protein_MevA", "Metabolite_MVA", "EnzymeActivity_MevA"]])


```

             Titer_gL  GeneExp_MevA  Flux_MVA  Protein_MevA  Metabolite_MVA  \
    Cluster                                                                   
    0        4.675000     39.500000  2.200000    141.400000        3.280000   
    1        3.668333     50.033333  3.621667     80.300000        2.598333   
    2        3.063529     53.705882  3.222353    127.588235        2.571176   
    
             EnzymeActivity_MevA  
    Cluster                       
    0                  97.350000  
    1                  83.233333  
    2                  79.170588  



```python
#reates both a heatmap and a pairplot using Seaborn#
# 🔬 Visualize omics correlations: heatmap + pairplot
import seaborn as sns
import matplotlib.pyplot as plt

omics_cols = [
    "GeneExp_MevA", "Flux_MVA", "Protein_MevA",
    "Metabolite_MVA", "EnzymeActivity_MevA", "Titer_gL"
]

omics_data = df[omics_cols]

# Heatmap of correlation coefficients
plt.figure(figsize=(10, 8))
sns.heatmap(omics_data.corr(), annot=True, cmap="viridis", linewidths=0.5)
plt.title("Omics Feature Correlation Heatmap")
plt.show()

# Pairplot to visualize relationships
sns.pairplot(omics_data, diag_kind="kde", corner=True)
plt.suptitle("Omics Feature Pairplot", y=1.02)
plt.show()

```


![png](output_9_0.png)



![png](output_9_1.png)



```python
import seaborn as sns
import matplotlib.pyplot as plt

omics_cols = [
    "GeneExp_MevA", "Flux_MVA", "Protein_MevA",
    "Metabolite_MVA", "EnzymeActivity_MevA", "Titer_gL"
]

omics_data = df[omics_cols]

sns.pairplot(omics_data, diag_kind="kde", corner=True)
plt.suptitle("Omics Feature Pairplot", y=1.02)
plt.show()

```


![png](output_10_0.png)



```python
cluster_summary = df.groupby("Cluster").mean(numeric_only=True)
cluster_summary

#github repo save#
plt.figure(figsize=(10, 8))
sns.heatmap(df[omics_cols].corr(), annot=True, cmap="viridis")
plt.title("Omics Feature Correlation Heatmap")
plt.savefig("results/omics_heatmap.png", dpi=300, bbox_inches="tight")
plt.close()

sns.pairplot(df[omics_cols], diag_kind="kde", corner=True)
plt.savefig("results/pairplot.png", dpi=300, bbox_inches="tight")
plt.close()

plt.figure(figsize=(6, 5))
plt.scatter(pca_coords[:, 0], pca_coords[:, 1], c=labels, cmap="viridis", s=80, edgecolors="k")
plt.title("PCA Cluster Plot")
plt.savefig("results/pca_clusters.png", dpi=300, bbox_inches="tight")
plt.close()

```


    ---------------------------------------------------------------------------

    FileNotFoundError                         Traceback (most recent call last)

    <ipython-input-27-29df750b8541> in <module>
          6 sns.heatmap(df[omics_cols].corr(), annot=True, cmap="viridis")
          7 plt.title("Omics Feature Correlation Heatmap")
    ----> 8 plt.savefig("results/omics_heatmap.png", dpi=300, bbox_inches="tight")
          9 plt.close()
         10 


    /opt/conda/lib/python3.7/site-packages/matplotlib/pyplot.py in savefig(*args, **kwargs)
        721 def savefig(*args, **kwargs):
        722     fig = gcf()
    --> 723     res = fig.savefig(*args, **kwargs)
        724     fig.canvas.draw_idle()   # need this if 'transparent=True' to reset colors
        725     return res


    /opt/conda/lib/python3.7/site-packages/matplotlib/figure.py in savefig(self, fname, transparent, **kwargs)
       2201             self.patch.set_visible(frameon)
       2202 
    -> 2203         self.canvas.print_figure(fname, **kwargs)
       2204 
       2205         if frameon:


    /opt/conda/lib/python3.7/site-packages/matplotlib/backend_bases.py in print_figure(self, filename, dpi, facecolor, edgecolor, orientation, format, bbox_inches, **kwargs)
       2103                     orientation=orientation,
       2104                     bbox_inches_restore=_bbox_inches_restore,
    -> 2105                     **kwargs)
       2106             finally:
       2107                 if bbox_inches and restore_bbox:


    /opt/conda/lib/python3.7/site-packages/matplotlib/backends/backend_agg.py in print_png(self, filename_or_obj, metadata, pil_kwargs, *args, **kwargs)
        533         else:
        534             renderer = self.get_renderer()
    --> 535             with cbook.open_file_cm(filename_or_obj, "wb") as fh:
        536                 _png.write_png(renderer._renderer, fh, self.figure.dpi,
        537                                metadata={**default_metadata, **metadata})


    /opt/conda/lib/python3.7/contextlib.py in __enter__(self)
        110         del self.args, self.kwds, self.func
        111         try:
    --> 112             return next(self.gen)
        113         except StopIteration:
        114             raise RuntimeError("generator didn't yield") from None


    /opt/conda/lib/python3.7/site-packages/matplotlib/cbook/__init__.py in open_file_cm(path_or_file, mode, encoding)
        416 def open_file_cm(path_or_file, mode="r", encoding=None):
        417     r"""Pass through file objects and context-manage `.PathLike`\s."""
    --> 418     fh, opened = to_filehandle(path_or_file, mode, True, encoding)
        419     if opened:
        420         with fh:


    /opt/conda/lib/python3.7/site-packages/matplotlib/cbook/__init__.py in to_filehandle(fname, flag, return_opened, encoding)
        401             fh = bz2.BZ2File(fname, flag)
        402         else:
    --> 403             fh = open(fname, flag, encoding=encoding)
        404         opened = True
        405     elif hasattr(fname, 'seek'):


    FileNotFoundError: [Errno 2] No such file or directory: 'results/omics_heatmap.png'



![png](output_11_1.png)

